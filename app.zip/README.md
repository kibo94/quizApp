# quizApp
Quiz app in vanila Js
